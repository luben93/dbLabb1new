package controller;

import java.awt.EventQueue;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Album;
import view.View;




/**
 * the actual controller, handle all communication between the view and the
 * model
 * 
 * @author luben and steffe
 * 
 */
public class driver {
	// private ArrayList<String> test;
	private View frame;
	private ArrayList<Album> results;
	
	private Connection con = null;
	//private ArrayList<String> colname;
	private String ip = "83.250.249.187", user = "steffe", pwd = "stefanborivalla", database = "labb1a";

	/**
	 * start is the equivalent of the constructor
	 */
	public void start() {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new View(driver.this);
					frame.setVisible(true);
				} catch (Exception e) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"Could not start program, " + e.toString());
					// e.printStackTrace();// test only
				}
			}
		});
		String server = "jdbc:mysql://" + ip + ":3306/" + database
				+ "?UseClientEnc=UTF8";

		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con = DriverManager.getConnection(server, user, pwd);
		} catch (Exception e) {
			javax.swing.JOptionPane.showMessageDialog(null, "Database error, "
					+ e.toString());
		} 
	}
		public void terminateCon(){
		try {
			if (con != null) {
				con.close();
			}
		} catch (SQLException e) {
			javax.swing.JOptionPane.showMessageDialog(null,
					"Database error, " + e.toString());
		}
		
	}

	/**
	 * update contains a insert SQL statment
	 * 
	 * @param artist
	 * @param album
	 * @param genre
	 * @throws SQLException 
	 */
	public void AddTransaction(String artist, String album, String genre)
			throws SQLException {
		if (!artist.equals("") && !album.equals("")) {
			
			//TODO TRANSAKTION. KLAR
		//	connect("insert into artist (idartist) values ('" + artist + "')", 
		//			"insert into album (albumid, genre) values ('" + album + "','" + genre + "')",
		//			"insert into album_artist (album, artist) values ('" + album + "','" + artist + "')",
		//			"AddTransaction");
			AddTransaction AddTran = new AddTransaction(con);
			AddTran.execute("insert into artist (idartist) values ('" + artist + "')",
					"insert into album (albumid, genre) values ('" + album + "','" + genre + "')",
					"insert into album_artist (album, artist) values ('" + album + "','" + artist + "')");
		} else {
			throw new NullValueExecption("Null is not an acceptable value here)");
		}
	}
	public void AddAnotherArtistToAlbum(String artist, String album) throws SQLException {
			if (!artist.equals("")) {
				
				//TODO LAGRAD PRECEDUR. KLAR 
				   CallableStatement cStmt = con.prepareCall("{call checkArtist(?)}");
				    cStmt.setString(1, artist);
				int hadResults = cStmt.executeUpdate();
				
				System.out.println("HEJ !");
				//connect("insert into album_artist (album, artist) values ('" + album + "','" + artist + "')", 
				//		null,
				//		null,
				//		"update");
				SQLupdate update = new SQLupdate(con);
				update.execute("insert into album_artist (album, artist) values ('" + album + "','" + artist + "')");
				
				
			} else {
				throw new NullValueExecption("Null is not an acceptable value here");
			}
	}

	/**
	 * Search contains a select SQL statment
	 * 
	 * @param SearchOn
	 * 				
	 * @param SearchedText
	 * 
	 * @param Table
	 * @throws SQLException 
	 */
	
	//TODO SEARCH
	public void Search(String SearchColumn, String SearchedText, String Table) throws SQLException {
		//connect("Select * FROM " + Table + " where " + SearchColumn + " like '" + SearchedText
			//	+ "%'", null,null,"query");
		ResultSet rs;
		SQLquery query = new SQLquery(con);
		query.execute("Select albumid, genre, rating, artist FROM album, album_artist "
				+ "where " + SearchColumn + " like '" + SearchedText
				+ "%' AND album.albumid = album_artist.album");
		results =  query.getResults();
//		rs = query.getResults();
//		results=new ArrayList<Album>();
//		while (rs.next()) {
//		results.add(new Album(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
//		}

	}
	
	//TODO 
	/**
	 * selects all
	 * @throws SQLException 
	 */
	public void selectAll() throws SQLException {
		
		SQLquery query = new SQLquery(con);
		query.execute("Select albumid, genre, rating, artist FROM album, album_artist where album.albumid = album_artist.album ");
		results =  query.getResults();
		//		ResultSet rs;
//		results=new ArrayList<Album>();
//		rs = query.getResults();
//		while (rs.next()) {
//			results.add(new Album(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
//		}
	}

	/**
	 * updates rating
	 * 
	 * @param rating
	 * @param album
	 * @throws SQLException 
	 */
	
	//TODO SEARCH F�RST. TYP KLAR MEN SEARCH ?
	public void updateRating(String rating, String SelectedRow) throws SQLException {
		SQLupdate update = new SQLupdate(con);
		System.out.println(SelectedRow);
		update.execute("update album set rating = '" + rating + "' where albumid ='"
				+ SelectedRow + "'");
		//connect("update album set rating = '" + rating + "' where albumid ='"
			//	+ SelectedRow + "'", null, null, "update");

	}

	//@SuppressWarnings("unchecked")
	public ArrayList<Album> getLatestQueryResults() {
		return (ArrayList<Album>) results.clone();
	}


	/**
	 * connect, connects to a database
	 * 
	 * @param sql
	 * @param type
	 *            is either update, (transaction) or query depending on the nature of the
	 *            SQLstatement
	 */
	/*public void connect(String sql, String sql2,String sql3,String type) {
		String server = "jdbc:mysql://" + ip + ":3306/" + database
				+ "?UseClientEnc=UTF8";

		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con = DriverManager.getConnection(server, user, pwd);
			// System.out.println("Connected!");

			switch (type) {
			case "AddTransaction":
				AddTransaction AddTran = new AddTransaction(con);
				AddTran.execute(sql,sql2,sql3);
				break;
			case "update":
				SQLupdate update = new SQLupdate(con);
				update.execute(sql);
				break;
			/*case "query":
				SQLquery query = new SQLquery(con);
				query.execute(sql);
				results = query.getResults();
				break;
			}
			

		} catch (Exception e) {
			javax.swing.JOptionPane.showMessageDialog(null, "Database error, "
					+ e.toString());
			// e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
					// System.out.println("Connection closed.");
				}
			} catch (SQLException e) {
				javax.swing.JOptionPane.showMessageDialog(null,
						"Database error, " + e.toString());
			}
		}

	}*/

}
